
Parent sets and their scores for the data sets from:
T. Silander and P. Myllymaki,
"A simple approach for finding the globally optimal
Bayesian network structure".

Ex. Data         n   N       T1      T2    D1   D2  S1           S2
------------------------------------------------------------------------------
1   balance      5   625     0       0     1    1   4549.055	 4521.018
2   iris         5   150     0       0     2    1   452.214	 465.435
3   thyroid      6   215     0       0     2    1   577.521	 602.069
4   liver        7   345     0       0     1    1   1309.673	 1321.963
5   ecoli        8   336     0       0     2    1   1715.923	 1778.743
6   abalone      9   4177    0       0     3    2   15946.575	 16171.192
7   diabetes     9   768     0       0     1    1   3678.573	 3692.797
8   post-op      9   90      0       0     0    0   647.353	 645.003
9   yeast        9   1484    0       0     1    1   7938.598	 8039.975
10  bc          10   286     0       0     1    1   2781.622	 2785.975
11  shuttle     10   58000   0       0     5    3   97635.720	 98774.355
12  tic-tac     10   958     1       0     3    3   9423.068	 9396.376
13  bc-wisc     11   699     0       0     2    2   3315.512	 3334.100
14  glass       11   214     0       0     4    1   1288.926	 1365.864
15  pg-block    11   5473    0       0     3    2   12455.597	 12711.762
16  heart-cl    14   303     5       4     1    1   3450.065	 3430.489
17  heart-hu    14   294     4       3     4    4   2376.529	 2384.007
18  heart-st    14   270     5       4     1    1   2867.537	 2860.866
19  wine        14   178     3       3     2    2   1866.406	 1891.695
20  adult       15   32561   334     314   4    4   329373.730	 330559.759
21  aus         15   690     10      7     2    2   4997.835	 5011.102
22  credit      16   690     32      24    2    2   6185.724	 6392.480
23  letter      17   20000   603     523   5    4   200768.883	 209774.055
24  voting      17   435     77      45    3    3   3192.667	 3205.785
25  zoo         17   101     18      11    7    2   642.259	 773.486
26  tumor       18   339     95      73    3    2   3191.186	 3194.252
27  lympho      19   148     171     147   13   2   1908.353	 1972.636
28  vehicle     19   846     391     288   4    2   7545.560	 7965.403
29  hepatitis   20   155     332     263   13   2   1615.682	 1647.970
30  segment     20   2310    774     387   5    3   14281.785	 15171.605
------------------------------------------------------------------------------

n = number of variables
N = number of data records
T1 = running time when using BDe score (seconds)
T2 = running time when using BIC score (seconds)
D1 = maximum parents when using BDe score
D2 = maximum parents when using BIC score
S1 = optimal score of network when using BDe score
S2 = optimal score of network when using BIC score

